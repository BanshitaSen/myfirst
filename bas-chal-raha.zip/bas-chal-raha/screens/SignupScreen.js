// screens/SignupScreen.js
import React from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const SignupScreen = ({
  username,
  setUsername,
  email,
  setEmail,
  password,
  setPassword,
  onSignup,
}) => (
  <View style={styles.container}>
    <Text style={styles.title}>SIGNUP at BS Grocery World</Text>
    <TextInput
      style={styles.input}
      placeholder="enter username"
      value={username}
      onChangeText={setUsername}
    />
    <TextInput
      style={styles.input}
      placeholder="enter mail id"
      value={email}
      onChangeText={setEmail}
    />
    <TextInput
      style={styles.input}
      placeholder="set password"
      value={password}
      onChangeText={setPassword}
      secureTextEntry
    />
    <Button title="Signup" onPress={onSignup} />
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '132b0e',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    fontWeight: 'bold',
    fontStyle: 'italic',
    color: 'blue',
  },

  input: {
    width: '100%',
    padding: 8,
    marginVertical: 8,
    borderWidth: 1,
    borderColor: 'red',
    borderRadius: 4,
    fontSize: 18, 
  },
});

export default SignupScreen;
