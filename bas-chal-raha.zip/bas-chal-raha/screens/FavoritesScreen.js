// FavoritesScreen.js
import React from 'react';
import { View, Text, Image, ScrollView, StyleSheet, Button } from 'react-native';
import { useFavorites } from '../context/FavoritesContext';

const FavoritesScreen = ({ onBack }) => {
  const { favorites, removeFavorite } = useFavorites();

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Your Favorites</Text>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {favorites.map(product => (
          <View key={product.id} style={styles.productCard}>
            <Image source={{ uri: product.image }} style={styles.image} />
            <Text style={styles.name}>{product.name}</Text>
            <Text style={styles.description}>{product.description}</Text>
            <Button title="Remove from Favorites" onPress={() => removeFavorite(product.id)} />
          </View>
        ))}
      </ScrollView>
      <Button title="Back" onPress={onBack} style={styles.backButton} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    width: '100%',
  },
  scrollContainer: {
    paddingBottom: 20,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  productCard: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
    marginBottom: 20,
    alignItems: 'center',
  },
  image: {
    width: 150,
    height: 150,
    marginBottom: 10,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  description: {
    textAlign: 'center',
  },
});
export default FavoritesScreen;
