import React from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const LoginScreen = ({
  username,
  setUsername,
  password,
  setPassword,
  onLogin,
}) => (
  <View style={styles.container}>
    <Text style={styles.title}>Login</Text>
    <TextInput
      style={styles.input}
      placeholder="Username"
      onChangeText={setUsername}
    />
    <TextInput
      style={styles.input}
      placeholder="Password"
      onChangeText={setPassword}
      secureTextEntry
    />
    <Button title="Login" onPress={onLogin} />
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    fontWeight: 'bold',
    fontStyle: 'italic',
    color: 'blue',
  },

  input: {
    width: '100%',
    padding: 8,
    marginVertical: 8,
    borderWidth: 1,
    borderColor: 'red',
    borderRadius: 4,
    fontSize: 18, 
  },
});

export default LoginScreen;
