import React, { useState } from 'react';
import { View, Text, StyleSheet, Switch } from 'react-native';

const DetailsScreen = () => {
  const [switchOn, setSwitchOn] = useState(false);

  const toggleSwitch = () => {
    setSwitchOn(previousState => !previousState);
  };

  return (
    <View style={[styles.container, { backgroundColor: switchOn ? '#e0e0e0' : '#fff' }]}>
      <View style={styles.contentContainer}>
        <Text style={styles.detailsText}>Details Screen</Text>
      </View>
      <View style={styles.switchContainer}>
        <Text>Toggle Background Color</Text>
        <Switch
          trackColor={{ false: '#767577', true: '#81b0ff' }}
          thumbColor={switchOn ? '#f5dd4b' : '#f4f3f4'}
          ios_backgroundColor="#3e3e3e"
          onValueChange={toggleSwitch}
          value={switchOn}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  detailsText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 10,
    backgroundColor: '#f0f0f0',
    borderTopWidth: 1,
    borderTopColor: '#ccc',
  },
});

export default DetailsScreen;
