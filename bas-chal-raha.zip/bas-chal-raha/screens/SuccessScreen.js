
// screens/SuccessScreen.js
import React from 'react';
import { View, ImageBackground, Text, Button, StyleSheet } from 'react-native';

const SuccessScreen = ({ onGoToProducts, onLogout }) => (
  <View style={styles.container}>
  <ImageBackground source={image} resizeMode="cover" style={styles.image}>
   <Text style={styles.title}>Welcome to BS Grocery World</Text>
   <Text style={styles.subtitle}>Freshness Delivered Daily</Text>
    <Button title="Go to Products" onPress={onGoToProducts} />
   
    </ImageBackground>
  </View>
);
const image = {uri: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Green_Color.jpg/640px-Green_Color.jpg'};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    marginBottom: 20,
    color: '#990F02',
    fontSize: 40,
    alignContent: 'center',
    padding: 80,
    fontWeight: 'bold',
    fontStyle: 'italic',
  },
  image: {
    width: '100%',
    height: '100%',
    flex: 1,
    justifyContent: 'center',
  },
   subtitle: {
    fontSize: 26,
    color: '#D21404',
    marginBottom: 75,
    textAlign: 'center',
    fontStyle: 'italic',
  },
 });


export default SuccessScreen;
