// ProductScreen.js
import React ,{ useState }  from 'react';
import { View, Text, Image, ScrollView, StyleSheet, Button, Switch } from 'react-native';
import { useFavorites } from '../context/FavoritesContext';

const ProductScreen = ({ username, onLogout }) => {
  const { addFavorite } = useFavorites();
  const [isDarkMode, setIsDarkMode] = useState(false);
  const toggleSwitch = () => setIsDarkMode(previousState => !previousState);
const products = [
  { id: 1, name: '1kg Carrot', description: 'Rs 68/-', image: 'https://upload.wikimedia.org/wikipedia/commons/d/dc/Carrot-fb.jpg', section: 'Vegetables' },
  { id: 2, name: '1kg Broccoli', description: 'Rs 109/-', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Broccoli_bunches.jpg/640px-Broccoli_bunches.jpg', section: 'Vegetables' },
  { id: 3, name: '1kg Cabbage', description: 'Rs 48/-', image: 'https://upload.wikimedia.org/wikipedia/commons/1/14/CabbageBG.JPG', section: 'Vegetables' },
  { id: 4, name: '1kg Capsicum', description: 'Rs 73/-', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Green-Yellow-Red-Pepper-2009.jpg/1024px-Green-Yellow-Red-Pepper-2009.jpg', section: 'Vegetables' },
  { id: 5, name: 'Apple', description: 'Rs 11/- per piece', image: 'https://upload.wikimedia.org/wikipedia/commons/c/c1/Fuji_apple.jpg', section: 'Fruits' },
  { id: 6, name: 'Banana', description: 'Rs 4/- per piece', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Bananas.jpg/1024px-Bananas.jpg', section: 'Fruits' },
  { id: 7, name: 'Orange', description: 'Rs 9/- per piece', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f9/Orange_and_cross_section.jpg/1200px-Orange_and_cross_section.jpg', section: 'Fruits' },
  { id: 8, name: '1 kg Grapes', description: 'Rs 56/-', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Grapes_in_a_bowl.JPG/1200px-Grapes_in_a_bowl.JPG', section: 'Fruits' },
  { id: 9, name: '1 kg Kelloggs Muesli', description: 'Rs 399/-', image: 'https://m.media-amazon.com/images/I/71BsckBgy3L.jpg', section: 'Cereals' },
  { id: 10, name: '2 kg Aashirvaad Atta', description: 'Rs 299/- ', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/02/Atta-04.jpg/800px-Atta-04.jpg', section: 'Cereals' },
  { id: 11, name: '5 kg Basmati Rice', description: 'Rs 799/-', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f8/Basmati_Rice_India%2C_raw.jpg/2560px-Basmati_Rice_India%2C_raw.jpg', section: 'Cereals' }, 
];


  const sections = [...new Set(products.map(product => product.section))];

  return (
    <View style={[styles.container, { backgroundColor: isDarkMode ? '#0c2000' : 'yellow' }]}>
      <Text style={[styles.welcome, { color: isDarkMode ? 'white' : '#0c2000' }]}>Welcome{username}!</Text>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {sections.map(section => (
          <View key={section} style={styles.section}>
            <Text style={[styles.sectionTitle, { color: isDarkMode ? 'white' : '#0c2000' }]}>{section}</Text>
            {products.filter(product => product.section === section).map(product => (
              <View key={product.id} style={styles.productCard}>
                <Image source={{ uri: product.image }} style={styles.image} />
                <Text style={styles.name}>{product.name}</Text>
                <Text style={styles.description}>{product.description}</Text>
                <Button title="Add to Favorites" onPress={() => addFavorite(product)} />
              </View>
            ))}
          </View>
        ))}
      </ScrollView>
      <View style={styles.switchContainer}>
        <Switch
          trackColor={{ false: 'grey', true: 'grey' }}
          thumbColor={isDarkMode ? 'white' : 'blue'}
          ios_backgroundColor="grey"
          onValueChange={toggleSwitch}
          value={isDarkMode}
        />
      </View>
      <Button title="Logout" onPress={onLogout} style={styles.logoutButton} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    width: '100%',
  },
  welcome: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  scrollContainer: {
    paddingBottom: 20,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  productCard: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
    marginBottom: 20,
    alignItems: 'center',
  },
  image: {
    width: 150,
    height: 150,
    marginBottom: 10,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  description: {
    textAlign: 'center',
  },
  switchContainer: {
    marginTop: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoutButton: {
    marginTop: 20,
  },
});


export default ProductScreen;
