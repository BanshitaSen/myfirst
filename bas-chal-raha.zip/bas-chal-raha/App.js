// App.js
import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import WelcomeScreen from './screens/WelcomeScreen';
import SignupScreen from './screens/SignupScreen';
import LoginScreen from './screens/LoginScreen';
import SuccessScreen from './screens/SuccessScreen';
import ProductScreen from './screens/ProductScreen';
import FavoritesScreen from './screens/FavoritesScreen';
import { FavoritesProvider } from './context/FavoritesContext';

const App = () => {
  const [screen, setScreen] = useState('Welcome');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSignup = () => {
    setScreen('Login');
  };

  const handleLogin = () => {
    setScreen('Success');
  };

  const handleLogout = () => {
    setUsername('');
    setEmail('');
    setPassword('');
    setScreen('Welcome');
  };

  return (
    <FavoritesProvider>
      <View style={styles.container}>
        {screen === 'Welcome' && <WelcomeScreen onSignup={() => setScreen('Signup')} />}
        {screen === 'Signup' && (
          <SignupScreen
            username={username}
            setUsername={setUsername}
            email={email}
            setEmail={setEmail}
            password={password}
            setPassword={setPassword}
            onSignup={handleSignup}
          />
        )}
        {screen === 'Login' && (
          <LoginScreen
            username={username}
            setUsername={setUsername}
            password={password}
            setPassword={setPassword}
            onLogin={handleLogin}
          />
        )}
        {screen === 'Success' && (
          <SuccessScreen
            onGoToProducts={() => setScreen('Product')}
            onGoToFavorites={() => setScreen('Favorites')}
          />
        )}
        {screen === 'Product' && <ProductScreen onLogout={handleLogout} />}
        {screen === 'Favorites' && <FavoritesScreen onBack={() => setScreen('Product')} />}
      </View>
    </FavoritesProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#65fe08',
    fontSize: 16,
    fontWeight: 'bold',
    fontStyle: 'italic',
  },
});

export default App;
